<?php 
class SDC {
//URL
const URL = "http://localhost:8081/";
//Navigation
const ROOT_PATH = "C:/xampp/htdocs";
const SUBFOLDER = "WebGlue/";
const SERVER_FOLDER = "SERVERS/";
const CONTROLLER_PATH = "/GateController.php";
//Data Connection
const IP = "127.0.0.1:3306";
const DATABASE_NAME = "test2";
const DB_USERNAME = "root";
const DB_PASS = "";
//Encryption
const SESS_CIPHER = "aes-128-cbc";
const KEYWORD = "fghgjgfhj";
}